Basic Express API Server to serve iOS Application

npm install express
npm install body-parser
npm install cors
npm install mongoose
